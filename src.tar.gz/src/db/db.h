#pragma once

#include <mutex>
#include <memory>
#include "common/utils.h"
#include "common/log.h"

#ifdef LEVELDB
#include "leveldb/options.h"
#include "leveldb/slice.h"
#include "leveldb/status.h"
#include "leveldb/write_batch.h"
#include "leveldb/cache.h"
#include "leveldb/filter_policy.h"
#include "leveldb/db.h"
#else
#include "rocksdb/options.h"
#include "rocksdb/slice.h"
#include "rocksdb/status.h"
#include "rocksdb/write_batch.h"
#include "rocksdb/filter_policy.h"
#include "rocksdb/db.h"
#endif

namespace shardora {

namespace db {

#ifdef LEVELDB
    typedef leveldb::WriteBatch TmpDbWriteBatch;
    typedef leveldb::Status DbStatus;
    typedef leveldb::DB DickDb;
    typedef leveldb::WriteOptions DbWriteOptions;
    typedef leveldb::ReadOptions DbReadOptions;
    typedef leveldb::Slice DbSlice;
    typedef leveldb::Iterator DbIterator;
#else
    typedef rocksdb::WriteBatch TmpDbWriteBatch;
    typedef rocksdb::Status DbStatus;
    typedef rocksdb::DB DickDb;
    typedef rocksdb::WriteOptions DbWriteOptions;
    typedef rocksdb::ReadOptions DbReadOptions;
    typedef rocksdb::Slice DbSlice;
    typedef rocksdb::Iterator DbIterator;
#endif // LEVELDB

class DbWriteBatch {
public:
    DbWriteBatch() {}
    DbWriteBatch(const DbWriteBatch&) = default;
    DbWriteBatch& operator =(const DbWriteBatch&) = default;
    ~DbWriteBatch() {
        Clear();
    }

    void Put(const std::string& key, const std::string& value) {
        if (data_map_.find(key) == data_map_.end()) {
            data_map_[key] = value;
        }

        db_batch_.Put(key, value);
    }

    bool Exist(const std::string& key) {
        return data_map_.find(key) != data_map_.end();
    }

    bool Get(const std::string& key, std::string* value) {
        auto iter = data_map_.find(key);
        if (iter == data_map_.end()) {
            return false;
        }
        
        *value = iter->second;
        return true;
    }

    void Delete(const std::string& key) {
        auto iter = data_map_.find(key);
        if (iter != data_map_.end()) {
            data_map_.erase(iter);
            db_batch_.Delete(key);
        }
    }

    void Clear() {
        data_map_.clear();
        db_batch_.Clear();
    }

    size_t ApproximateSize() const {
#ifdef LEVELDB
        return db_batch_.ApproximateSize();
#else
        return data_map_.size() > 0 ? 100 : 0;
#endif
    }

    TmpDbWriteBatch db_batch_;
    std::unordered_map<std::string, std::string> data_map_;
};

class Db {
public:
    Db();
    ~Db();
    bool Init(const std::string& db_path);
    void Destroy();
    bool Exist(const std::string& key) {
        DbIterator* it = db_->NewIterator(DbReadOptions());
        it->Seek(key);
        bool res = false;
        if (it->Valid() && it->key().size() == key.size() &&
                memcmp(it->key().data(), key.c_str(), key.size()) == 0) {
            res = true;
        }

        delete it;
        return res;
    }

    DbStatus Put(DbWriteBatch& db_batch) {
        if (db_batch.ApproximateSize() <= 12) {
            return db::DbStatus();
        }

        DbWriteOptions write_opt;
        auto st = db_->Write(write_opt, &db_batch.db_batch_);
        db_batch.Clear();
        return st;
    }

    DbStatus Put(const std::string& key, const std::string& value) {
        DbWriteOptions write_opt;
        return db_->Put(write_opt, DbSlice(key), DbSlice(value));
    }

    DbStatus Put(const std::string& key, const char* value, size_t len) {
        DbWriteOptions write_opt;
        return db_->Put(write_opt, DbSlice(key), DbSlice(value, len));
    }

    DbStatus Get(const std::string& key, std::string* value) {
        DbReadOptions read_opt;
        return db_->Get(read_opt, DbSlice(key), value);
    }

    std::vector<DbStatus> Get(const std::vector<DbSlice>& keys, std::vector<std::string>* value) {
        DbReadOptions read_opt;
        return std::vector<DbStatus>();
//         return db_->MultiGet(read_opt, keys, value);
    }

    DbStatus Delete(const std::string& key) {
        DbWriteOptions write_opt;
        return db_->Delete(write_opt, DbSlice(key));
    }

    void ClearPrefix(const std::string& prefix) {
        DbReadOptions option;
        auto iter = db_->NewIterator(option);
        iter->Seek(prefix);
        int32_t valid_count = 0;
        while (iter->Valid()) {
            if (memcmp(prefix.c_str(), iter->key().data(), prefix.size()) != 0) {
                break;
            }

            DbWriteOptions write_opt;
            db_->Delete(write_opt, iter->key());
            ++valid_count;
            iter->Next();
        }

        delete iter;
    }

    void GetAllPrefix(const std::string& prefix, std::map<std::string, std::string>& res_map) {
        DbReadOptions option;
        auto iter = db_->NewIterator(option);
        iter->Seek(prefix);
        int32_t valid_count = 0;
        while (iter->Valid()) {
            if (memcmp(prefix.c_str(), iter->key().data(), prefix.size()) != 0) {
                break;
            }

            res_map[iter->key().ToString()] = iter->value().ToString();
            iter->Next();
        }
    }

    DickDb* db() {
        return db_;
    }

    DickDb* db_ = nullptr;

private:
    Db(const Db&);
    Db(const Db&&);
    Db& operator=(const Db&);
    bool inited_{ false };
    std::mutex mutex;
};

}  // db

}  // zjchain
