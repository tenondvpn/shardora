#pragma once

#include <deque>

#include "block/block_utils.h"
#include "ck/ck_client.h"
#include "common/config.h"
#include "common/limit_hash_map.h"
#include "common/node_members.h"
#include "common/thread_safe_queue.h"
#include "common/tick.h"
#include "contract/contract_manager.h"
#include "db/db.h"
#include "network/network_utils.h"
#include "pools/to_txs_pools.h"
#include "protos/block.pb.h"
#include "protos/zbft.pb.h"
#include "protos/prefix_db.h"
#include "protos/transport.pb.h"
#include "security/security.h"
#include "transport/multi_thread.h"
#include "transport/transport_utils.h"

namespace shardora {

namespace pools{
    class TxPoolManager;
    class ShardStatistic;
}

namespace block {

class AccountManager;
class BlockManager {
public:
    BlockManager(transport::MultiThreadHandler& net_handler_);
    ~BlockManager();
    int Init(
        std::shared_ptr<AccountManager>& account_mgr,
        std::shared_ptr<db::Db>& db,
        std::shared_ptr<pools::TxPoolManager>& pools_mgr,
        std::shared_ptr<pools::ShardStatistic>& statistic_mgr,
        std::shared_ptr<security::Security>& security,
        std::shared_ptr<contract::ContractManager>& contract_mgr,
        const std::string& local_id,
        DbBlockCallback new_block_callback,
        block::BlockAggValidCallback block_agg_valid_func);
    int NetworkNewBlock(
        const std::shared_ptr<block::protobuf::Block>& block_item,
        const bool need_valid);
    // just for genesis create new block
    void GenesisNewBlock(
        const std::shared_ptr<block::protobuf::Block>& block_item);
    void OnTimeBlock(
        uint64_t lastest_time_block_tm,
        uint64_t latest_time_block_height,
        uint64_t vss_random);
    void ConsensusAddBlock(
        const BlockToDbItemPtr& block_item);
    int GetBlockWithHeight(
        uint32_t network_id,
        uint32_t pool_index,
        uint64_t height,
        block::protobuf::Block& block_item);
    void NewBlockWithTx(
        const std::shared_ptr<block::protobuf::Block>& block_item,
        const block::protobuf::BlockTx& tx,
        db::DbWriteBatch& db_batch);
    void SetMaxConsensusShardingId(uint32_t sharding_id) {
        max_consensus_sharding_id_ = sharding_id;
    }

    void SetCreateToTxFunction(pools::CreateConsensusItemFunction func) {
        create_to_tx_cb_ = func;
    }

    void SetCreateStatisticTxFunction(pools::CreateConsensusItemFunction func) {
        create_statistic_tx_cb_ = func;
    }

    void SetCreateElectTxFunction(pools::CreateConsensusItemFunction func) {
        create_elect_tx_cb_ = func;
    }

    void CreateToTx();
    void OnNewElectBlock(uint32_t sharding_id, uint64_t elect_height, common::MembersPtr& members);
    pools::TxItemPtr GetToTx(uint32_t pool_index, const std::string& tx_hash);
    pools::TxItemPtr GetStatisticTx(uint32_t pool_index, const std::string& tx_hash);
    pools::TxItemPtr GetElectTx(uint32_t pool_index, const std::string& tx_hash);
    void LoadLatestBlocks();
    // just genesis call
    void GenesisAddAllAccount(
        uint32_t des_sharding_id,
        const std::shared_ptr<block::protobuf::Block>& block_item,
        db::DbWriteBatch& db_batch);
    void GenesisAddOneAccount(uint32_t des_sharding_id,
                              const block::protobuf::BlockTx& tx,
                              const uint64_t& latest_height,
                              db::DbWriteBatch& db_batch);
    void ChangeLeader(int32_t mod_num, common::BftMemberPtr& mem_ptr);
    bool ShouldStopConsensus();
    int FirewallCheckMessage(transport::MessagePtr& msg_ptr);
    bool HasSingleTx(uint32_t pool_index);

private:
    typedef std::map<uint64_t, std::shared_ptr<BlockTxsItem>, std::greater<uint64_t>> StatisticMap;
    bool HasToTx(uint32_t pool_index);
    bool HasStatisticTx(uint32_t pool_index);
    bool HasElectTx(uint32_t pool_index);
    void HandleAllNewBlock();
    bool UpdateBlockItemToCache(
        std::shared_ptr<block::protobuf::Block>& block,
        db::DbWriteBatch& db_batch);
    void HandleMessage(const transport::MessagePtr& msg_ptr);
    void ConsensusTimerMessage(const transport::MessagePtr& message);
    void HandleToTxsMessage(const transport::MessagePtr& msg_ptr, bool recreate);
    void HandleAllConsensusBlocks();
    void AddNewBlock(
        const std::shared_ptr<block::protobuf::Block>& block_item,
        db::DbWriteBatch& db_batch);
    void HandleNormalToTx(
        const block::protobuf::Block& block,
        const block::protobuf::BlockTx& tx,
        db::DbWriteBatch& db_batch);
    void HandleStatisticTx(
        const block::protobuf::Block& block,
        const block::protobuf::BlockTx& tx,
        db::DbWriteBatch& db_batch);
    void HandleElectTx(
        const block::protobuf::Block& block,
        const block::protobuf::BlockTx& tx,
        db::DbWriteBatch& db_batch);
    void HandleLocalNormalToTx(
        const pools::protobuf::ToTxMessage& to_txs,
        uint32_t step,
        const std::string& heights_hash);
    void createConsensusLocalToTxs(
        std::unordered_map<std::string, std::shared_ptr<localToTxInfo>> addr_amount_map,
        const std::string& heights_hash);
    void createContractCreateByRootToTxs(
        std::vector<std::shared_ptr<localToTxInfo>> contract_create_tx_infos,
        const std::string& heights_hash);
    void HandleJoinElectTx(
        const block::protobuf::Block& block,
        const block::protobuf::BlockTx& tx,
        db::DbWriteBatch& db_batch);
    void AddMiningToken(
        const std::string& block_hash,
        const elect::protobuf::ElectBlock& elect_block);
    void RootHandleNormalToTx(
        const block::protobuf::Block& block,
        pools::protobuf::ToTxMessage& to_txs,
        db::DbWriteBatch& db_batch);
    void HandleStatisticBlock(
        const block::protobuf::Block& block,
        const block::protobuf::BlockTx& tx,
        const pools::protobuf::ElectStatistic& elect_statistic,
        db::DbWriteBatch& db_batch);
    void CreateStatisticTx();
    void HandleToTxMessage();
    void AddWaitingCheckSignBlock(const std::shared_ptr<block::protobuf::Block>& block_ptr);
    void CheckWaitingBlocks(uint32_t shard, uint64_t elect_height);
    void PopTxTicker();

    static const uint64_t kCreateToTxPeriodMs = 10000lu;
    static const uint64_t kRetryStatisticPeriod = 3000lu;
    static const uint64_t kStatisticTimeoutMs = 20000lu;
    static const uint64_t kToTimeoutMs = 10000lu;
    static const uint64_t kStatisticValidTimeout = 15000lu;
    static const uint64_t kToValidTimeout = 1500lu;
    static const uint64_t kElectTimeout = 20000lu;
    static const uint64_t kElectValidTimeout = 3000000lu;

    std::shared_ptr<AccountManager> account_mgr_ = nullptr;
    common::ThreadSafeQueue<BlockToDbItemPtr>* consensus_block_queues_ = nullptr;
    std::shared_ptr<db::Db> db_ = nullptr;
    std::shared_ptr<protos::PrefixDb> prefix_db_ = nullptr;
    std::shared_ptr<pools::TxPoolManager> pools_mgr_ = nullptr;
    std::shared_ptr<pools::ToTxsPools> to_txs_pool_ = nullptr;
    std::shared_ptr<security::Security> security_ = nullptr;
    uint64_t prev_create_to_tx_ms_ = 0;
    uint64_t prev_retry_create_statistic_tx_ms_ = 0;
    common::BftMemberPtr to_tx_leader_ = nullptr;
    uint32_t max_consensus_sharding_id_ = 3;
    std::string local_id_;
    std::map<uint64_t, std::shared_ptr<LeaderWithToTxItem>, std::greater<uint64_t>> leader_to_txs_;
    std::shared_ptr<LeaderWithToTxItem> latest_to_tx_ = nullptr;
    std::shared_ptr<BlockTxsItem> shard_elect_tx_[network::kConsensusShardEndNetworkId];
    pools::CreateConsensusItemFunction create_to_tx_cb_ = nullptr;
    pools::CreateConsensusItemFunction create_statistic_tx_cb_ = nullptr;
    pools::CreateConsensusItemFunction create_elect_tx_cb_ = nullptr;
    uint32_t prev_pool_index_ = network::kRootCongressNetworkId;
    std::shared_ptr<ck::ClickHouseClient> ck_client_ = nullptr;
    uint64_t prev_to_txs_tm_us_ = 0;
    DbBlockCallback new_block_callback_ = nullptr;
    std::shared_ptr<pools::ShardStatistic> statistic_mgr_ = nullptr;
    uint64_t latest_timeblock_height_ = 0;
    uint64_t prev_timeblock_tm_sec_ = 0;
    uint64_t latest_timeblock_tm_sec_ = 0;
    uint64_t prev_timeblock_height_ = 0;
    uint64_t consensused_timeblock_height_ = 0;
    std::unordered_map<uint32_t, std::map<
        uint64_t,
        std::shared_ptr<pools::protobuf::ElectStatistic>>> shard_timeblock_statistic_;
    transport::MultiThreadHandler& net_handler_;
    block::BlockAggValidCallback block_agg_valid_func_ = nullptr;
    std::shared_ptr<pools::protobuf::ToTxHeights> statistic_heights_ptr_ = nullptr;
//     std::shared_ptr<pools::protobuf::ToTxHeights> to_tx_heights_ptr_ = nullptr;
    common::MembersPtr latest_members_ = nullptr;
    uint64_t latest_elect_height_ = 0;
    int32_t leader_create_to_heights_index_ = 0;
    int32_t leader_create_statistic_heights_index_ = 0;
    StatisticMap shard_statistics_map_;
    common::ThreadSafeQueue<std::shared_ptr<StatisticMap>> shard_statistics_map_ptr_queue_;
    std::shared_ptr<StatisticMap> got_latest_statistic_map_ptr_[2] = { nullptr };
    uint32_t valid_got_latest_statistic_map_ptr_index_ = 0;
    common::ThreadSafeQueue<std::shared_ptr<block::protobuf::Block>> block_from_network_queue_[common::kMaxThreadCount];
    common::ThreadSafeQueue<std::shared_ptr<transport::TransportMessage>> to_tx_msg_queue_;
    common::ThreadSafeQueue<std::shared_ptr<transport::TransportMessage>> statistic_tx_msg_queue_;
    std::map<uint32_t, std::map<uint64_t, std::queue<std::shared_ptr<block::protobuf::Block>>>> waiting_check_sign_blocks_;
    std::shared_ptr<contract::ContractManager> contract_mgr_ = nullptr;
    uint64_t prev_create_statistic_tx_tm_us_ = 0;
    uint64_t prev_timer_ms_ = 0;
    common::Tick pop_tx_tick_;

    DISALLOW_COPY_AND_ASSIGN(BlockManager);
};

}  // namespace block

}  // namespace shardora

