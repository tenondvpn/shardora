# protobuf version: 3.6.1
protoc --proto_path=/root/shardora/src protos/*.proto --cpp_out=./
