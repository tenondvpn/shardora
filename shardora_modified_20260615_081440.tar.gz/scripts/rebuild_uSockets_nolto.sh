#!/usr/bin/env bash
# Rebuild libuSockets.a without LTO (fixes "LTO version 15.1 instead of 13.1" at link time).
set -euo pipefail
SETH_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
USOCKETS_DIR=""
if [ -f "$SETH_ROOT/third_party/uSockets/src/libusockets.h" ]; then
    USOCKETS_DIR="$SETH_ROOT/third_party/uSockets"
elif [ -f "$SETH_ROOT/third_party/uWebSockets/uSockets/src/libusockets.h" ]; then
    USOCKETS_DIR="$SETH_ROOT/third_party/uWebSockets/uSockets"
else
    cd "$SETH_ROOT/third_party/uWebSockets"
    git submodule update --init --recursive 2>/dev/null || true
    cd "$SETH_ROOT"
    git submodule update --init third_party/uSockets third_party/uWebSockets 2>/dev/null || true
    if [ -f "$SETH_ROOT/third_party/uSockets/src/libusockets.h" ]; then
        USOCKETS_DIR="$SETH_ROOT/third_party/uSockets"
    elif [ -f "$SETH_ROOT/third_party/uWebSockets/uSockets/src/libusockets.h" ]; then
        USOCKETS_DIR="$SETH_ROOT/third_party/uWebSockets/uSockets"
    else
        echo "uSockets source not found under third_party/uSockets or third_party/uWebSockets/uSockets"
        exit 1
    fi
fi

cd "$USOCKETS_DIR"
rm -f ./*.o ./*.a
CC="${CC:-cc}"
CXX="${CXX:-c++}"
AR="${AR:-ar}"
"${CC}" -O3 -fPIC -fno-lto -DLIBUS_USE_OPENSSL -std=c11 -Isrc \
    -c src/*.c src/eventing/*.c src/crypto/*.c src/io_uring/*.c
"${CXX}" -O3 -fPIC -fno-lto -DLIBUS_USE_OPENSSL -std=c++17 -Isrc \
    -c src/crypto/*.cpp
"${AR}" rvs uSockets.a ./*.o
mkdir -p "$SETH_ROOT/third_party/lib"
cp -f uSockets.a "$SETH_ROOT/third_party/lib/libuSockets.a"
printf 'no-lto openssl\n' > "$SETH_ROOT/third_party/lib/libuSockets.no_lto.openssl.stamp"
echo "OK: $SETH_ROOT/third_party/lib/libuSockets.a (no LTO)"
echo "Reconfigure seth build without LTO, e.g.:"
echo "  cd cbuild_Release && cmake .. -DSETH_ENABLE_LTO=OFF && make -j\$(nproc) seth"
