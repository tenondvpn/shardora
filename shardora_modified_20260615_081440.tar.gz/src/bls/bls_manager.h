#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <unordered_map>

#include "common/bitmap.h"
#include "bls/bls_dkg.h"
#include "bls/bls_utils.h"
#include "security/security.h"

namespace seth {

namespace bls {

class DkgCache;

class IBlsManager {
public:
    IBlsManager() {};
    virtual ~IBlsManager() {};

    virtual int Sign(
            uint32_t t,
            uint32_t n,
            const libff::alt_bn128_Fr& local_sec_key,
            const libff::alt_bn128_G1& g1_hash,
            std::string* sign_x,
            std::string* sign_y) = 0;
    virtual int Verify(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_G2& pubkey,
        const libff::alt_bn128_G1& sign,
        const libff::alt_bn128_G1& g1_hash,
        std::string* verify_hash) = 0;
    virtual int VerifyFast(
        const libff::alt_bn128_G1& sign,
        const libff::alt_bn128_G1& g1_hash,
        const libff::alt_bn128_G2& pkey) = 0;
    virtual int GetVerifyHash(
            uint32_t t,
            uint32_t n,
            const libff::alt_bn128_G1& g1_hash,
            const libff::alt_bn128_G2& pkey,
            std::string* verify_hash) = 0;

    virtual int GetVerifyHash(
            uint32_t t,
            uint32_t n,
            const libff::alt_bn128_G1& sign,
            std::string* verify_hash) = 0;

    virtual int GetLibffHash(const std::string& str_hash, libff::alt_bn128_G1* g1_hash) = 0;
    virtual std::shared_ptr<security::Security> security() = 0;
};

class BlsManager : public IBlsManager {
public:
    BlsManager(
        std::shared_ptr<security::Security>& security,
        std::shared_ptr<db::Db>& db,
        std::shared_ptr<ck::ClickHouseClient> ck_client);
    ~BlsManager();
    void OnNewElectBlock(
        uint32_t sharding_id,
        uint64_t elect_height,
        uint64_t prev_elect_height,
        const std::shared_ptr<elect::protobuf::ElectBlock>& elect_block);
    void OnTimeBlock(
        uint64_t lastest_time_block_tm,
        uint64_t latest_time_block_height,
        uint64_t vss_random);
    void SetUsedElectionBlock(
        uint64_t elect_height,
        uint32_t network_id,
        uint32_t member_count,
        const libff::alt_bn128_G2& common_public_key);
    int Sign(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_Fr& local_sec_key,
        const libff::alt_bn128_G1& g1_hash,
        std::string* sign_x,
        std::string* sign_y);
    int Sign(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_Fr& sec_key,
        const libff::alt_bn128_G1& g1_hash,
        libff::alt_bn128_G1* bn_sign);
    int Verify(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_G2& pubkey,
        const libff::alt_bn128_G1& sign,
        const libff::alt_bn128_G1& g1_hash,
        std::string* verify_hash);
    int VerifyFast(
        const libff::alt_bn128_G1& sign,
        const libff::alt_bn128_G1& g1_hash,
        const libff::alt_bn128_G2& pkey);
    int GetVerifyHash(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_G1& g1_hash,
        const libff::alt_bn128_G2& pkey,
        std::string* verify_hash);
    int GetVerifyHash(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_G1& sign,
        std::string* verify_hash);
    int GetLibffHash(const std::string& str_hash, libff::alt_bn128_G1* g1_hash);
    int AddBlsConsensusInfo(elect::protobuf::ElectBlock& ec_block);
    int CheckBlsConsensusInfo(const elect::protobuf::ElectBlock& ec_block);
    void HandleMessage(const transport::MessagePtr& msg_ptr);
    int FirewallCheckMessage(transport::MessagePtr& msg_ptr);
    std::shared_ptr<security::Security> security() {
        return security_;
    }
    void PoolTimerMessage();

private:
    void HandleFinish(const transport::MessagePtr& msg_ptr);
    void HandleFinishSyncRequest(const transport::MessagePtr& msg_ptr);
    void SyncFinishMessageToNeighbors(uint32_t network_id);
    void BatchVerifyFinishItems();
    void CheckAggSignValid(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_G2& common_pk,
        BlsFinishItemPtr& finish_item,
        uint32_t member_idx);
    bool VerifyAggSignValid(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_G2& common_pk,
        BlsFinishItemPtr& finish_item,
        std::vector<libff::alt_bn128_G1>& all_signs,
        std::vector<size_t>& idx_vec);
    bool CheckAndVerifyAll(
        uint32_t t,
        uint32_t n,
        const libff::alt_bn128_G2& common_pk,
        BlsFinishItemPtr& finish_item,
        std::vector<libff::alt_bn128_G1>& all_signs,
        std::vector<size_t>& idx_vec);
    void ResetLeaders(
        const common::MembersPtr& members,
        elect::protobuf::PrevMembers* prev_members);
    void PopFinishMessage();
    int CheckFinishMessageValid(const transport::MessagePtr& msg_ptr);
    void TimerMessage();

    std::shared_ptr<bls::BlsDkg> LoadWaitingBls() const {
        std::lock_guard<std::mutex> lock(waiting_bls_mutex_);
        return waiting_bls_;
    }

    void StoreWaitingBls(const std::shared_ptr<bls::BlsDkg>& waiting_bls) {
        std::lock_guard<std::mutex> lock(waiting_bls_mutex_);
        waiting_bls_ = waiting_bls;
    }

    std::shared_ptr<TimeBlockItem> LoadLatestTimeblockInfo() const {
        std::lock_guard<std::mutex> lock(latest_timeblock_info_mutex_);
        return latest_timeblock_info_;
    }

    void StoreLatestTimeblockInfo(const std::shared_ptr<TimeBlockItem>& timeblock_info) {
        std::lock_guard<std::mutex> lock(latest_timeblock_info_mutex_);
        latest_timeblock_info_ = timeblock_info;
    }

    std::shared_ptr<bls::BlsDkg> waiting_bls_{ nullptr };
    mutable std::mutex waiting_bls_mutex_;
    uint64_t max_height_{ common::kInvalidUint64 };
    std::unordered_map<uint32_t, BlsFinishItemPtr> finish_networks_map_;
    std::shared_ptr<security::Security> security_ = nullptr;
    std::shared_ptr<db::Db> db_ = nullptr;
    std::shared_ptr<protos::PrefixDb> prefix_db_ = nullptr;
    std::shared_ptr<TimeBlockItem> latest_timeblock_info_ = nullptr;
    mutable std::mutex latest_timeblock_info_mutex_;
    uint64_t latest_elect_height_ = 0;
    std::unordered_map<uint32_t, std::shared_ptr<ElectItem>> elect_members_;
    common::Tick bls_tick_;
    common::ThreadSafeQueue<std::shared_ptr<transport::TransportMessage>> finish_msg_queue_;
    std::shared_ptr<ck::ClickHouseClient> ck_client_ = nullptr;
    std::shared_ptr<DkgCache> dkg_cache_ = nullptr;

    DISALLOW_COPY_AND_ASSIGN(BlsManager);
};


};  // namespace bls

};  // namespace seth
