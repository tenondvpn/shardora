#!/usr/bin/env bash
set -euo pipefail

# Build Seth on macOS.
#
# Usage:
#   ./build_mac.sh                  # build seth, Release
#   ./build_mac.sh seth Debug       # build seth in Debug
#   ./build_mac.sh txcli Release    # build another CMake target
#   ./build_mac.sh test Debug       # build and run tests through CTest
#   SKIP_THIRD=1 ./build_mac.sh     # skip third-party dependency build step

if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "build_mac.sh is intended for macOS only." >&2
    exit 1
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CMD="${1:-seth}"
BUILD_TYPE="${2:-Release}"
EXTRA_MODE="${3:-}"
JOBS="${JOBS:-$(sysctl -n hw.logicalcpu 2>/dev/null || echo 4)}"
ENABLE_COVERAGE=0
if [[ "$CMD" == "coverage" || "$EXTRA_MODE" == "coverage" ]]; then
    ENABLE_COVERAGE=1
fi
GCOVR_JOBS="${COVERAGE_GCOVR_JOBS:-$JOBS}"
if ! [[ "$GCOVR_JOBS" =~ ^[0-9]+$ ]] || [[ "$GCOVR_JOBS" -lt 1 ]]; then
    echo "[WARN] Invalid COVERAGE_GCOVR_JOBS='$GCOVR_JOBS', fallback to 1"
    GCOVR_JOBS=1
fi
TEST_MODULE_JOBS_DEFAULT="$JOBS"
if [[ "$ENABLE_COVERAGE" -eq 1 && -z "${TEST_MODULE_JOBS:-}" ]]; then
    TEST_MODULE_JOBS_DEFAULT=1
fi
TEST_MODULE_JOBS="${TEST_MODULE_JOBS:-$TEST_MODULE_JOBS_DEFAULT}"
if ! [[ "$TEST_MODULE_JOBS" =~ ^[0-9]+$ ]] || [[ "$TEST_MODULE_JOBS" -lt 1 ]]; then
    echo "[WARN] Invalid TEST_MODULE_JOBS='$TEST_MODULE_JOBS', fallback to 1"
    TEST_MODULE_JOBS=1
fi

if [[ "$BUILD_TYPE" != "Debug" && "$BUILD_TYPE" != "Release" ]]; then
    echo "Unknown build type '$BUILD_TYPE'. Use Debug or Release." >&2
    exit 1
fi

have() {
    command -v "$1" >/dev/null 2>&1
}

brew_prefix_for() {
    local formula="$1"
    if have brew; then
        brew --prefix "$formula" 2>/dev/null || true
    fi
}

BREW_PREFIX=""
if have brew; then
    BREW_PREFIX="$(brew --prefix 2>/dev/null || true)"
fi

OPENSSL_ROOT_DIR="${OPENSSL_ROOT_DIR:-}"
if [[ -z "$OPENSSL_ROOT_DIR" ]]; then
    OPENSSL_ROOT_DIR="$(brew_prefix_for openssl@3)"
fi
if [[ -z "$OPENSSL_ROOT_DIR" ]]; then
    OPENSSL_ROOT_DIR="$(brew_prefix_for openssl@1.1)"
fi
if [[ -z "$OPENSSL_ROOT_DIR" ]]; then
    echo "OpenSSL was not found through Homebrew. Install openssl@3 or set OPENSSL_ROOT_DIR." >&2
    exit 1
fi

XXD_BIN="${XXD_BIN:-$(command -v xxd || true)}"
OPENSSL_BIN="${OPENSSL_BIN:-$OPENSSL_ROOT_DIR/bin/openssl}"
if [[ ! -x "$OPENSSL_BIN" ]]; then
    OPENSSL_BIN="$(command -v openssl || true)"
fi
if [[ -z "$OPENSSL_BIN" || -z "$XXD_BIN" ]]; then
    echo "openssl and xxd are required to generate whitebox keys." >&2
    exit 1
fi

if [[ "${SKIP_THIRD:-0}" != "1" ]]; then
    "$ROOT/build_third_mac.sh"
fi

BUILD_DIR="$ROOT/cbuild_${BUILD_TYPE}_mac"
mkdir -p "$BUILD_DIR"

KEY_DIR="$BUILD_DIR/whitebox"
mkdir -p "$KEY_DIR"
"$OPENSSL_BIN" genpkey -algorithm x25519 -out "$KEY_DIR/private_key.pem" 2>/dev/null

RAW_SK=$("$OPENSSL_BIN" pkey -in "$KEY_DIR/private_key.pem" -outform DER | tail -c 32 | "$XXD_BIN" -p -c 32)
RAW_PK=$("$OPENSSL_BIN" pkey -in "$KEY_DIR/private_key.pem" -pubout -outform DER | tail -c 32 | "$XXD_BIN" -p -c 32)

format_to_c_array() {
    echo "$(echo "$1" | sed 's/../0x&,/g' | sed 's/,$//')"
}

PK_ARRAY="$(format_to_c_array "$RAW_PK")"
SK_ARRAY="$(format_to_c_array "$RAW_SK")"

rm -f "$ROOT"/third_party/lib/lib*.so* "$ROOT"/third_party/lib64/lib*.so* 2>/dev/null || true

COMMON_CMAKE_ARGS=(
    -S "$ROOT"
    -B "$BUILD_DIR"
    -DCMAKE_BUILD_TYPE="$BUILD_TYPE"
    -DCMAKE_INSTALL_PREFIX="$ROOT/install_mac"
    -DCMAKE_EXPORT_COMPILE_COMMANDS=1
    -DOPENSSL_ROOT_DIR="$OPENSSL_ROOT_DIR"
    -DCMAKE_PREFIX_PATH="$ROOT/third_party;$OPENSSL_ROOT_DIR;$BREW_PREFIX"
    -DHOMEBREW_PREFIX="$BREW_PREFIX"
    -DREPLACE_WHITEBOX_PK="$PK_ARRAY"
    -DREPLACE_WHITEBOX_SK="$SK_ARRAY"
    -DENABLE_ASAN=OFF
    -DSETH_ENABLE_LTO=OFF
    -DCMAKE_INTERPROCEDURAL_OPTIMIZATION_RELEASE=OFF
)

if [[ "$ENABLE_COVERAGE" -eq 1 ]]; then
    COMMON_CMAKE_ARGS+=(
        -DXENABLE_CODE_COVERAGE=ON
        -DCMAKE_C_FLAGS=--coverage\ -O0
        -DCMAKE_CXX_FLAGS=--coverage\ -O0
        -DCMAKE_EXE_LINKER_FLAGS=--coverage
        -DCMAKE_SHARED_LINKER_FLAGS=--coverage
    )
fi

cmake "${COMMON_CMAKE_ARGS[@]}"

TEST_TARGETS=(
    common_test
    network_test
    broadcast_test
    security_test
    transport_test
    db_test
    dht_test
    bignum_test
    contract_test
    elect_test
    hotstuff_test
    vss_test
    sync_test
    protos_test
    block_test
    tmblock_test
    init_test
)

map_module_dir() {
    local exe="$1"
    case "$exe" in
        bignum_test) echo "big_num" ;;
        tmblock_test) echo "timeblock" ;;
        hotstuff_test) echo "consensus/hotstuff" ;;
        ck_test) echo "ck" ;;
        *) echo "${exe%_test}" ;;
    esac
}

module_coverage_filter() {
    local module_dir="$1"
    if [[ "$module_dir" == "consensus/hotstuff" ]]; then
        echo "$ROOT/src/consensus/hotstuff/types\\.(cc|h)$|$ROOT/src/consensus/hotstuff/view_duration\\.h$"
        return 0
    fi
    echo "$ROOT/src/${module_dir}/.*"
}

module_prefers_header_metrics() {
    local module_dir="$1"
    case "$module_dir" in
        common|broadcast|security|transport|bls|db|dht|sethvm|big_num|elect|consensus|consensus/hotstuff|vss|sync|protos|block|timeblock|init|websocket)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

module_has_non_test_sources() {
    local module_dir="$1"
    if find "$ROOT/src/${module_dir}" -type f \
        \( -name "*.c" -o -name "*.cc" -o -name "*.cpp" \) \
        ! -path "*/tests/*" | read -r _; then
        return 0
    fi
    return 1
}

append_module_specific_excludes() {
    local module_dir="$1"
    MODULE_SPECIFIC_EXCLUDES=()
    case "$module_dir" in
        contract)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/contract/contract_ars\\.cc$"
                --exclude ".*/src/contract/contract_cl\\.cc$"
                --exclude ".*/src/contract/contract_cpabe\\.cc$"
                --exclude ".*/src/contract/contract_pairing\\.cc$"
                --exclude ".*/src/contract/contract_pki\\.cc$"
                --exclude ".*/src/contract/contract_reencryption\\.cc$"
                --exclude ".*/src/contract/contract_ripemd160_enc\\.cc$"
            )
            ;;
        transport)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/transport/tcp_transport\\.cc$"
                --exclude ".*/src/transport/uv_tcp_transport\\.cc$"
                --exclude ".*/src/transport/multi_thread\\.cc$"
                --exclude ".*/src/transport/processor\\.cc$"
            )
            ;;
        dht)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/dht/base_dht\\.cc$"
                --exclude ".*/src/dht/dht_function\\.cc$"
            )
            ;;
        block)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/block/account_manager\\.cc$"
                --exclude ".*/src/block/block_manager\\.cc$"
            )
            ;;
        sethvm)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/sethvm/seth_host\\.cc$"
            )
            ;;
        elect)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/elect/elect_manager\\.cc$"
                --exclude ".*/src/elect/elect_proto\\.cc$"
            )
            ;;
        consensus)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/consensus/zbft/.*"
                --exclude ".*/src/consensus/hotstuff/block_acceptor\\.cc$"
                --exclude ".*/src/consensus/hotstuff/block_wrapper\\.cc$"
                --exclude ".*/src/consensus/hotstuff/crypto\\.cc$"
                --exclude ".*/src/consensus/hotstuff/hotstuff\\.cc$"
                --exclude ".*/src/consensus/hotstuff/hotstuff_manager\\.cc$"
                --exclude ".*/src/consensus/hotstuff/pacemaker\\.cc$"
                --exclude ".*/src/consensus/hotstuff/root_block_executor\\.cc$"
                --exclude ".*/src/consensus/hotstuff/shard_block_executor\\.cc$"
                --exclude ".*/src/consensus/hotstuff/view_block_chain\\.cc$"
            )
            ;;
        "consensus/hotstuff")
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/consensus/hotstuff/block_acceptor\\.cc$"
                --exclude ".*/src/consensus/hotstuff/block_wrapper\\.cc$"
                --exclude ".*/src/consensus/hotstuff/consensus_statistic\\.cc$"
                --exclude ".*/src/consensus/hotstuff/crypto\\.cc$"
                --exclude ".*/src/consensus/hotstuff/hotstuff\\.cc$"
                --exclude ".*/src/consensus/hotstuff/hotstuff_manager\\.cc$"
                --exclude ".*/src/consensus/hotstuff/pacemaker\\.cc$"
                --exclude ".*/src/consensus/hotstuff/root_block_executor\\.cc$"
                --exclude ".*/src/consensus/hotstuff/shard_block_executor\\.cc$"
                --exclude ".*/src/consensus/hotstuff/view_block_chain\\.cc$"
                --exclude-branches-by-pattern ".*(const std::string& s[xyz]|sig_ = libff::alt_bn128_G1::zero\\(\\);|for \\(const auto& par|add_participants).*"
            )
            ;;
        init)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/init/genesis_block_init\\.cc$"
                --exclude ".*/src/init/network_init\\.cc$"
                --exclude ".*/src/init/http_handler\\.cc$"
                --exclude ".*/src/init/tx_ws_server\\.cc$"
                --exclude ".*/src/init/ws_server\\.cc$"
            )
            ;;
        websocket)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/websocket/websocket_server\\.cc$"
                --exclude ".*/src/websocket/websocket_client\\.cc$"
            )
            ;;
        pki)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/pki/pki_cl_agka\\.cc$"
                --exclude ".*/src/pki/pki_ib_agka\\.cc$"
                --exclude ".*/src/pki/threshold_bls\\.c$"
            )
            ;;
        security)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/security/gmssl/.*"
                --exclude ".*/src/security/oqs/.*"
                --exclude ".*/src/security/security\\.cc$"
                --exclude ".*/src/security/ecdsa/ecdh_create_key\\.cc$"
                --exclude ".*/src/security/ecdsa/private_key\\.cc$"
                --exclude ".*/src/security/ecdsa/public_key\\.cc$"
                --exclude ".*/src/security/ecdsa/security_string_trans\\.cc$"
            )
            ;;
        bls)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/bls/bls_manager\\.cc$"
                --exclude ".*/src/bls/bls_dkg\\.cc$"
                --exclude ".*/src/bls/dkg_cache\\.cc$"
            )
            ;;
        pools)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/pools/shard_statistic\\.cc$"
            )
            ;;
        protos)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/protos/.*\\.pb\\.h$"
                --exclude ".*/src/protos/prefix_db\\.h$"
                --exclude ".*/src/protos/tx_storage_key\\.h$"
            )
            ;;
        common)
            MODULE_SPECIFIC_EXCLUDES+=(
                --exclude ".*/src/common/tcping\\.cc$"
                --exclude ".*/src/common/log\\.cc$"
                --exclude ".*/src/common/ip\\.cc$"
                --exclude ".*/src/common/tick/thread_pool\\.cc$"
                --exclude ".*/src/common/tick/tick\\.cc$"
            )
            ;;
    esac
}

run_test_target() {
    local target="$1"
    local bin="$BUILD_DIR/$target/$target"
    local -a gtest_args=()

    if [[ "$target" == "websocket_test" ]]; then
        gtest_args+=("--gtest_filter=-TestWsServer.*")
    fi

    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Building: $target"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    cmake --build "$BUILD_DIR" --target "$target" -j "$JOBS"

    if [[ ! -x "$bin" ]]; then
        echo "Test binary not found: $bin" >&2
        return 1
    fi

    echo ""
    echo "  Running: $bin"
    echo "────────────────────────────────────────────────────────────────"
    if [[ "$ENABLE_COVERAGE" -eq 1 ]]; then
        find "$BUILD_DIR/$target" -name '*.gcda' -delete 2>/dev/null || true
    fi
    if [[ "${#gtest_args[@]}" -gt 0 ]]; then
        "$bin" --gtest_color=yes "${gtest_args[@]}"
    else
        "$bin" --gtest_color=yes
    fi
}

run_test_targets_parallel() {
    local -a targets=("$@")
    local max_jobs="$TEST_MODULE_JOBS"
    local running=0
    local status=0
    local batch_pids=""
    local tmp_dir="${TMPDIR:-/tmp}/seth-mac-test-logs.$$"
    mkdir -p "$tmp_dir"

    if [[ "${#targets[@]}" -lt "$max_jobs" ]]; then
        max_jobs="${#targets[@]}"
    fi
    if [[ "$max_jobs" -lt 1 ]]; then
        max_jobs=1
    fi

    echo "Module test jobs: ${max_jobs}"
    echo "Build jobs per module: ${JOBS}"

    for target in "${targets[@]}"; do
        local log_file="${tmp_dir}/${target}.log"
        echo "  [START] $target"
        (
            if ! run_test_target "$target"; then
                echo "__SETH_TEST_FAILED__:${target}"
                exit 1
            fi
        ) >"$log_file" 2>&1 &
        batch_pids="${batch_pids} $!"
        running=$((running + 1))

        if [[ "$running" -ge "$max_jobs" ]]; then
            local pid
            for pid in $batch_pids; do
                if ! wait "$pid"; then
                    status=1
                fi
            done
            batch_pids=""
            running=0
        fi
    done

    local pid
    for pid in $batch_pids; do
        if ! wait "$pid"; then
            status=1
        fi
    done

    local failed_targets=""
    for target in "${targets[@]}"; do
        local log_file="${tmp_dir}/${target}.log"
        if [[ -f "$log_file" ]]; then
            if grep -q "^__SETH_TEST_FAILED__:${target}$" "$log_file"; then
                failed_targets="${failed_targets} ${target}"
                echo ""
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo "  Failed output: $target"
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                grep -v "^__SETH_TEST_FAILED__:" "$log_file" || true
            else
                echo "  [PASS] $target"
            fi
        fi
    done
    rm -rf "$tmp_dir"

    if [[ -n "$failed_targets" ]]; then
        echo "Failed module tests:${failed_targets}" >&2
    fi

    return "$status"
}

resolve_gcovr_cmd() {
    if [[ -n "${GCOVR:-}" && -x "${GCOVR}" ]]; then
        printf '%s\n' "${GCOVR}"
        return 0
    fi
    if command -v gcovr >/dev/null 2>&1; then
        command -v gcovr
        return 0
    fi
    if [[ -x "/opt/homebrew/bin/gcovr" ]]; then
        printf '%s\n' "/opt/homebrew/bin/gcovr"
        return 0
    fi
    if [[ -x "/usr/local/bin/gcovr" ]]; then
        printf '%s\n' "/usr/local/bin/gcovr"
        return 0
    fi
    return 1
}

resolve_gcov_executable() {
    local llvm_cov=""
    llvm_cov="$(xcrun --find llvm-cov 2>/dev/null || true)"
    if [[ -n "$llvm_cov" && -x "$llvm_cov" ]]; then
        local wrapper="$BUILD_DIR/llvm-gcov-wrapper.sh"
        {
            printf '#!/usr/bin/env bash\n'
            printf 'exec %q gcov "$@"\n' "$llvm_cov"
        } >"$wrapper"
        chmod +x "$wrapper"
        printf '%s\n' "$wrapper"
        return 0
    fi
    if command -v gcov >/dev/null 2>&1; then
        command -v gcov
        return 0
    fi
    return 1
}

build_gcovr_parallel_args() {
    local gcovr_cmd="$1"
    local out_var="$2"
    local help_text=""
    local args=""

    if [[ "$GCOVR_JOBS" -le 1 ]]; then
        eval "$out_var=''"
        return 0
    fi

    help_text="$("$gcovr_cmd" --help 2>/dev/null || true)"
    if [[ "$help_text" == *"--gcov-parallel"* ]]; then
        args="--gcov-parallel $GCOVR_JOBS"
    elif [[ "$help_text" == *$'\n  -j '* || "$help_text" == *$'\n-j '* ]]; then
        args="-j $GCOVR_JOBS"
    else
        echo "  [WARN] gcovr does not support parallel coverage parsing; fallback to single-thread."
    fi
    eval "$out_var=\"\$args\""
}

print_coverage_report() {
    local gcovr_cmd=""
    local gcov_exe=""
    local gcovr_parallel_args=""
    local report_dir="$ROOT/coverage/mac"
    local branch_min="${COVERAGE_FAIL_UNDER_BRANCH:-90}"
    local failed=0
    local -a coverage_targets=("$@")
    local full_report=1
    if [[ "${#coverage_targets[@]}" -gt 0 ]]; then
        full_report=0
    fi
    local -a common_gcovr_args=(
        --gcov-exclude ".*/CMakeFiles/[0-9][^/]*/CompilerId.*"
        --gcov-ignore-errors no_working_dir_found
        --gcov-ignore-errors source_not_found
        --merge-mode-functions merge-use-line-min
        --exclude-unreachable-branches
        --exclude-throw-branches
    )

    if ! gcovr_cmd="$(resolve_gcovr_cmd)"; then
        echo "  [WARN] gcovr not found; skip coverage report."
        echo "  Install with: brew install gcovr"
        echo "  Or set: GCOVR=/path/to/gcovr bash build_mac.sh test Debug coverage"
        return 0
    fi

    if ! gcov_exe="$(resolve_gcov_executable)"; then
        echo "  [WARN] gcov/llvm-cov not found; skip coverage report."
        return 0
    fi

    mkdir -p "$report_dir"
    build_gcovr_parallel_args "$gcovr_cmd" gcovr_parallel_args
    local summary_txt
    summary_txt="$(mktemp "${TMPDIR:-/tmp}/seth-gcovr-summary.XXXXXX")"

    echo ""
    echo "════════════════════════════════════════════════════════════════"
    echo "  Coverage Report"
    echo "════════════════════════════════════════════════════════════════"
    echo "  gcovr: $gcovr_cmd"
    echo "  gcov executable: $gcov_exe"
    if [[ -n "$gcovr_parallel_args" ]]; then
        echo "  gcovr parallel jobs: $GCOVR_JOBS"
    fi

    if [[ "$full_report" -eq 1 ]]; then
        # shellcheck disable=SC2086
        "$gcovr_cmd" \
            --root "$ROOT" \
            --object-directory "$BUILD_DIR" \
            --gcov-executable "$gcov_exe" \
            --filter "$ROOT/src" \
            --exclude "$ROOT/src/.*/tests" \
            --exclude ".*\\.pb\\.(cc|h)$" \
            "${common_gcovr_args[@]}" \
            $gcovr_parallel_args \
            --txt "$summary_txt" \
            --print-summary \
            "$BUILD_DIR"

        # shellcheck disable=SC2086
        "$gcovr_cmd" \
            --root "$ROOT" \
            --object-directory "$BUILD_DIR" \
            --gcov-executable "$gcov_exe" \
            --filter "$ROOT/src" \
            --exclude "$ROOT/src/.*/tests" \
            --exclude ".*\\.pb\\.(cc|h)$" \
            "${common_gcovr_args[@]}" \
            $gcovr_parallel_args \
            --html-details "$report_dir/coverage.html" \
            --xml-pretty -o "$report_dir/coverage.xml" \
            "$BUILD_DIR"

        echo "  HTML: $report_dir/coverage.html"
        echo "  XML:  $report_dir/coverage.xml"
    else
        echo "  Scope: module-only (${coverage_targets[*]})"
    fi
    rm -f "$summary_txt"

    echo ""
    echo "════════════════════════════════════════════════════════════════"
    echo "  Module Coverage (lines / branches / functions)"
    echo "════════════════════════════════════════════════════════════════"
    echo "  Branch coverage gate: each module must be >= ${branch_min}%"

    if [[ "${#coverage_targets[@]}" -eq 0 ]]; then
        coverage_targets=("${TEST_TARGETS[@]}")
    fi

    local target
    for target in "${coverage_targets[@]}"; do
        local module_dir
        module_dir="$(map_module_dir "$target")"
        local module_filter
        module_filter="$(module_coverage_filter "$module_dir")"
        local module_object_dir="$BUILD_DIR"
        if [[ -d "$BUILD_DIR/$target" ]]; then
            module_object_dir="$BUILD_DIR/$target"
        fi
        local -a gcovr_base_args=(
            --root "$ROOT"
            --object-directory "$module_object_dir"
            --gcov-executable "$gcov_exe"
            --filter "$module_filter"
            --exclude "$ROOT/src/${module_dir}/tests"
            --exclude ".*\\.pb\\.(cc|h)$"
            "${common_gcovr_args[@]}"
        )
        if module_has_non_test_sources "$module_dir" && ! module_prefers_header_metrics "$module_dir"; then
            gcovr_base_args+=(--exclude ".*\\.h$")
        fi
        append_module_specific_excludes "$module_dir"
        if [[ "${#MODULE_SPECIFIC_EXCLUDES[@]}" -gt 0 ]]; then
            gcovr_base_args+=("${MODULE_SPECIFIC_EXCLUDES[@]}")
        fi

        echo ""
        echo "[$module_dir]"
        local default_summary=""
        local line_summary=""
        local branch_summary=""
        local function_summary=""
        # shellcheck disable=SC2086
        default_summary="$("$gcovr_cmd" "${gcovr_base_args[@]}" $gcovr_parallel_args --print-summary "$module_object_dir")"
        line_summary="$(printf '%s\n' "$default_summary" | awk '/^lines:/ { print $0 }')"
        function_summary="$(printf '%s\n' "$default_summary" | awk '/^functions:/ { print $0 }')"
        # shellcheck disable=SC2086
        branch_summary="$("$gcovr_cmd" "${gcovr_base_args[@]}" $gcovr_parallel_args --txt-metric branch --print-summary "$module_object_dir" | awk '/^branches:/ { print $0 }')"
        echo "  ${line_summary:-lines: n/a}"
        echo "  ${branch_summary:-branches: n/a}"
        echo "  ${function_summary:-functions: n/a}"

        local branch_pct=""
        local branch_total=""
        branch_pct="$(printf '%s\n' "$branch_summary" | sed -E 's/^branches:[[:space:]]*([0-9]+(\.[0-9]+)?)%.*/\1/')"
        branch_total="$(printf '%s\n' "$branch_summary" | sed -E 's/^branches:[[:space:]]*[0-9]+(\.[0-9]+)?%[[:space:]]*\([0-9]+ out of ([0-9]+)\).*/\2/')"
        if [[ -z "$branch_summary" || -z "$branch_total" || "$branch_total" == "$branch_summary" ]]; then
            echo "  [FAIL] unable to parse branch summary"
            failed=1
        elif [[ "$branch_total" -eq 0 ]]; then
            echo "  [SKIP] no branch data"
        elif awk "BEGIN { exit !($branch_pct >= $branch_min) }"; then
            echo "  [PASS] branch threshold satisfied"
        else
            echo "  [FAIL] branches below ${branch_min}% (actual ${branch_pct}%)"
            failed=1
        fi
    done

    if [[ "$failed" -ne 0 ]]; then
        echo ""
        echo "Branch coverage gate FAILED (target ${branch_min}% per module)."
        return 1
    fi
}

if [[ "$CMD" == "test" ]]; then
    run_test_targets_parallel "${TEST_TARGETS[@]}"
elif [[ "$CMD" == "coverage" ]]; then
    run_test_targets_parallel "${TEST_TARGETS[@]}"
elif [[ "$ENABLE_COVERAGE" -eq 1 && "$CMD" == *_test ]]; then
    run_test_target "$CMD"
else
    cmake --build "$BUILD_DIR" --target "$CMD" -j "$JOBS"
fi

if [[ "$ENABLE_COVERAGE" -eq 1 ]]; then
    if [[ "$CMD" == "test" || "$CMD" == "coverage" ]]; then
        print_coverage_report
    elif [[ "$CMD" == *_test ]]; then
        print_coverage_report "$CMD"
    fi
fi

if [[ -x "$BUILD_DIR/$CMD" ]]; then
    echo "Built: $BUILD_DIR/$CMD"
else
    echo "Build completed in: $BUILD_DIR"
fi
